// ========================================
// VOTEX - VOTING SYSTEM
// FACE VERIFICATION + VOTING
// ========================================


// ========================================
// GLOBAL VARIABLES
// ========================================

window.activeElectionId = null;


// ========================================
// CHECK VOTER LOGIN
// ========================================

function checkVoterLogin() {

    const token =
        localStorage.getItem("voter_token");

    if (!token) {

        document.getElementById(
            "candidateList"
        ).innerHTML = `
            <p>
                Please login as a voter first.
            </p>
        `;

        document.getElementById(
            "voteButton"
        ).disabled = true;

        return false;
    }

    return true;
}


// ========================================
// CHECK FACE VERIFICATION
// ========================================

function checkFaceVerification() {

    const faceToken =
        localStorage.getItem("face_token");

    if (!faceToken) {

        document.getElementById(
            "candidateList"
        ).innerHTML = `
            <p>
                🔒 Face verification required
                before voting.
            </p>
        `;

        document.getElementById(
            "voteButton"
        ).disabled = true;

        return false;
    }

    return true;
}


// ========================================
// LOAD ACTIVE ELECTION
// ========================================

async function loadActiveElection() {

    try {

        const response =
            await fetch(
                "http://localhost:5000/api/election/active"
            );

        const election =
            await response.json();


        if (!response.ok) {

            document.getElementById(
                "candidateList"
            ).innerHTML = `
                <p>
                    ${election.message}
                </p>
            `;

            return;
        }


        window.activeElectionId =
            election.election_id;


        loadCandidates();

    }
    catch (error) {

        console.error(
            "Election Error:",
            error
        );


        document.getElementById(
            "candidateList"
        ).innerHTML =
            "<p>Unable to load active election.</p>";
    }
}


// ========================================
// LOAD CANDIDATES
// ========================================

async function loadCandidates() {

    try {

        const response =
            await fetch(
                "http://localhost:5000/api/candidate/all"
            );


        const candidates =
            await response.json();


        const candidateList =
            document.getElementById(
                "candidateList"
            );


        candidateList.innerHTML = "";


        if (
            !candidates ||
            candidates.length === 0
        ) {

            candidateList.innerHTML =
                "<p>No candidates available.</p>";

            return;
        }


        candidates.forEach(
            (candidate) => {

                const div =
                    document.createElement(
                        "div"
                    );


                div.innerHTML = `
                    <label>

                        <input
                            type="radio"
                            name="candidate"
                            value="${candidate.candidate_id}"
                        >

                        <strong>
                            ${candidate.full_name}
                        </strong>

                        - ${candidate.party_name}

                    </label>

                    <br><br>
                `;


                candidateList.appendChild(
                    div
                );
            }
        );


        // Enable vote button

        document.getElementById(
            "voteButton"
        ).disabled = false;


    }
    catch (error) {

        console.error(
            "Candidate Error:",
            error
        );


        document.getElementById(
            "candidateList"
        ).innerHTML =
            "<p>Unable to load candidates.</p>";
    }
}


// ========================================
// CAST VOTE
// ========================================

async function castVote() {

    // ========================================
    // GET JWT TOKEN
    // ========================================

    const token =
        localStorage.getItem(
            "voter_token"
        );


    // ========================================
    // CHECK LOGIN
    // ========================================

    if (!token) {

        document.getElementById(
            "message"
        ).innerHTML =
            "Please login as a voter first.";

        return;
    }


    // ========================================
    // GET FACE TOKEN
    // ========================================

    const faceToken =
        localStorage.getItem(
            "face_token"
        );


    // ========================================
    // CHECK FACE VERIFICATION
    // ========================================

    if (!faceToken) {

        document.getElementById(
            "message"
        ).innerHTML = `
            <p>
                🔒 Please complete face verification first.
            </p>

            <button
                onclick="window.location.href='face_verify.html'"
            >
                Verify Face
            </button>
        `;

        return;
    }


    // ========================================
    // GET SELECTED CANDIDATE
    // ========================================

    const selectedCandidate =
        document.querySelector(
            'input[name="candidate"]:checked'
        );


    if (!selectedCandidate) {

        document.getElementById(
            "message"
        ).innerHTML =
            "Please select a candidate.";

        return;
    }


    const candidate_id =
        selectedCandidate.value;


    const election_id =
        window.activeElectionId;


    // ========================================
    // CHECK ACTIVE ELECTION
    // ========================================

    if (!election_id) {

        document.getElementById(
            "message"
        ).innerHTML =
            "No active election found.";

        return;
    }


    // ========================================
    // DISABLE BUTTON
    // ========================================

    document.getElementById(
        "voteButton"
    ).disabled = true;


    document.getElementById(
        "message"
    ).innerHTML = `
        <p>
            🗳️ Casting your vote...
        </p>
    `;


    try {

        // ========================================
        // SEND VOTE TO BACKEND
        // ========================================

        const response =
            await fetch(
                "http://localhost:5000/api/vote/cast",
                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json",

                        // JWT
                        "Authorization":
                            "Bearer " + token,

                        // FACE VERIFICATION TOKEN
                        "X-Face-Token":
                            faceToken
                    },


                    body: JSON.stringify({

                        election_id:
                            election_id,

                        candidate_id:
                            candidate_id
                    })
                }
            );


        const data =
            await response.json();


        // ========================================
        // SUCCESS
        // ========================================

        if (response.ok) {

            document.getElementById(
                "message"
            ).innerHTML = `

                <h3>
                    ✅ Vote Cast Successfully!
                </h3>

                <p>
                    <strong>
                        Your Receipt Code:
                    </strong>
                </p>

                <p>
                    ${data.receipt_code}
                </p>

                <p>
                    <strong>
                        Blockchain Hash:
                    </strong>
                </p>

                <p style="word-break: break-all;">
                    ${data.blockchain_hash}
                </p>

                <p>
                    Please save your receipt code.
                </p>

            `;


            // ========================================
            // DISABLE VOTE BUTTON
            // ========================================

            document.getElementById(
                "voteButton"
            ).disabled = true;


            // ========================================
            // DISABLE CANDIDATES
            // ========================================

            const candidates =
                document.querySelectorAll(
                    'input[name="candidate"]'
                );


            candidates.forEach(
                (candidate) => {

                    candidate.disabled = true;

                }
            );


            // ========================================
            // REMOVE FACE TOKEN
            // ========================================

            localStorage.removeItem(
                "face_token"
            );

        }


        // ========================================
        // ERROR
        // ========================================

        else {

            document.getElementById(
                "message"
            ).innerHTML =
                "❌ " + data.message;


            document.getElementById(
                "voteButton"
            ).disabled = false;


            // If face token expired,
            // ask voter to verify again.

            if (
                response.status === 403
            ) {

                localStorage.removeItem(
                    "face_token"
                );

                document.getElementById(
                    "message"
                ).innerHTML = `

                    <p>
                        🔒 Face verification expired.
                    </p>

                    <button
                        onclick="window.location.href='face_verify.html'"
                    >
                        Verify Face Again
                    </button>

                `;
            }

        }


    }
    catch (error) {

        console.error(
            "Vote Error:",
            error
        );


        document.getElementById(
            "message"
        ).innerHTML =
            "❌ Unable to connect to server.";


        document.getElementById(
            "voteButton"
        ).disabled = false;
    }
}

// ========================================
// START
// ========================================

if (checkVoterLogin()) {

    const faceToken =
        localStorage.getItem("face_token");


    // ========================================
    // FACE NOT VERIFIED
    // ========================================

    if (!faceToken) {

        window.location.href =
            "face_verify.html";

    }


    // ========================================
    // FACE ALREADY VERIFIED
    // ========================================

    else {

        loadActiveElection();

    }

}