async function loadResults() {

    try {

        // ========================================
        // GET ACTIVE ELECTION
        // ========================================

        const electionResponse =
            await fetch(
                "http://localhost:5000/api/election/active"
            );


        const election =
            await electionResponse.json();


        document.getElementById(
            "electionName"
        ).innerHTML =
            election.election_name;


        // ========================================
        // GET RESULTS
        // ========================================

        const response =
            await fetch(
                `http://localhost:5000/api/result/${election.election_id}`
            );


        const data =
            await response.json();


        const resultList =
            document.getElementById(
                "resultList"
            );


        const winner =
            document.getElementById(
                "winner"
            );


        resultList.innerHTML = "";


        // ========================================
        // CHECK RESULTS
        // ========================================

        if (
            !data.results ||
            data.results.length === 0
        ) {

            resultList.innerHTML =
                "No votes have been cast yet.";

            winner.innerHTML =
                "No winner yet.";

            return;

        }


        // ========================================
        // TOTAL VOTES
        // ========================================

        let totalVotes = 0;


        data.results.forEach(candidate => {

            totalVotes +=
                Number(candidate.vote_count);

        });


        // ========================================
        // WINNER
        // ========================================

        const winningCandidate =
            data.results[0];


        winner.innerHTML = `

            <h2>
                🏆 Winner
            </h2>

            <h3>
                ${winningCandidate.full_name}
            </h3>

            <p>
                ${winningCandidate.party_name}
            </p>

            <p>
                <strong>
                    ${winningCandidate.vote_count}
                    Votes
                </strong>
            </p>

        `;


        // ========================================
        // DISPLAY ALL CANDIDATES
        // ========================================

        data.results.forEach(
            (candidate, index) => {

                const votes =
                    Number(
                        candidate.vote_count
                    );


                let percentage = 0;


                if (totalVotes > 0) {

                    percentage =
                        (
                            votes /
                            totalVotes
                        ) * 100;

                }


                let medal = "";


                if (index === 0) {

                    medal = "🥇";

                } else if (index === 1) {

                    medal = "🥈";

                } else if (index === 2) {

                    medal = "🥉";

                } else {

                    medal = "🏅";

                }


                const div =
                    document.createElement(
                        "div"
                    );


                div.innerHTML = `

                    <h3>
                        ${medal}
                        ${index + 1}.
                        ${candidate.full_name}
                    </h3>

                    <p>
                        Party:
                        ${candidate.party_name}
                    </p>

                    <p>
                        <strong>
                            Votes:
                        </strong>

                        ${votes}
                    </p>

                    <p>
                        <strong>
                            Vote Percentage:
                        </strong>

                        ${percentage.toFixed(2)}%
                    </p>

                    <hr>

                `;


                resultList.appendChild(
                    div
                );

            }
        );


        console.log(
            "Election Results:",
            data.results
        );


    } catch (error) {

        console.error(
            "Result Error:",
            error
        );


        document.getElementById(
            "resultList"
        ).innerHTML =
            "Unable to load election results.";

    }

}


// ========================================
// LOAD RESULTS WHEN PAGE OPENS
// ========================================

loadResults();