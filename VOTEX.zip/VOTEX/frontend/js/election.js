async function createElection() {

    try {

        const election_name =
            document.getElementById("election_name").value;

        const election_type =
            document.getElementById("election_type").value;

        const start_date =
            document.getElementById("start_date").value;

        const end_date =
            document.getElementById("end_date").value;

        const status =
            document.getElementById("status").value;

        const response = await fetch(
            "http://localhost:5000/api/election/create",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({

                    election_name,
                    election_type,
                    start_date,
                    end_date,
                    status

                })
            }
        );

        const data = await response.json();

        document.getElementById("message").innerHTML =
            data.message;

    } catch (error) {

        console.error(error);

        document.getElementById("message").innerHTML =
            "Error: " + error.message;

    }
}