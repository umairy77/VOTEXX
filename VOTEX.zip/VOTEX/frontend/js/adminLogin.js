async function loginAdmin() {

    const email =
        document.getElementById("email").value.trim();

    const password =
        document.getElementById("password").value.trim();


    // Check fields

    if (!email || !password) {

        document.getElementById("message").innerHTML =
            "Please enter email and password.";

        return;
    }


    try {

        const response = await fetch(
            "http://localhost:5000/api/admin/login",
            {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({

                    email,
                    password

                })

            }
        );


        const data =
            await response.json();


        document.getElementById(
            "message"
        ).innerHTML =
            data.message;


        // Login successful

        if (response.ok && data.admin) {

            localStorage.setItem(
                "admin_id",
                data.admin.admin_id
            );


            localStorage.setItem(
                "admin_name",
                data.admin.full_name
            );


            setTimeout(() => {

                window.location.href =
                    "admin_dashboard.html";

            }, 1000);

        }


    } catch (error) {

        console.error(error);


        document.getElementById(
            "message"
        ).innerHTML =
            "Unable to connect to server.";

    }

}