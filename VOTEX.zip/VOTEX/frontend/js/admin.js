async function registerAdmin(){

    const full_name=document.getElementById("full_name").value;

    const email=document.getElementById("email").value;

    const password=document.getElementById("password").value;

    const role=document.getElementById("role").value;

    const response=await fetch("http://localhost:5000/api/admin/register",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify({

            full_name,

            email,

            password,

            role

        })

    });

    const data=await response.json();

    document.getElementById("message").innerHTML=data.message;

}