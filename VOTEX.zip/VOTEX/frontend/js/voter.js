// ========================================
// VOTEX - VOTER REGISTRATION
// ========================================


// ========================================
// REGISTER VOTER
// ========================================

async function registerVoter() {

    // ========================================
    // GET FORM VALUES
    // ========================================

    const voter_number =
        document.getElementById("voter_number").value.trim();

    const full_name =
        document.getElementById("full_name").value.trim();

    const date_of_birth =
        document.getElementById("date_of_birth").value;

    const gender =
        document.getElementById("gender").value;

    const aadhaar =
        document.getElementById("aadhaar").value.trim();

    const mobile =
        document.getElementById("mobile").value.trim();

    const email =
        document.getElementById("email").value.trim();

    const address =
        document.getElementById("address").value.trim();

    const constituency =
        document.getElementById("constituency").value.trim();


    // ========================================
    // BASIC VALIDATION
    // ========================================

    if (
        !voter_number ||
        !full_name ||
        !date_of_birth ||
        !gender ||
        !aadhaar ||
        !mobile ||
        !email ||
        !address ||
        !constituency
    ) {

        document.getElementById("message").innerHTML =
            "Please fill all fields.";

        return;
    }


    // ========================================
    // SHOW LOADING MESSAGE
    // ========================================

    document.getElementById("message").innerHTML =
        "Registering voter...";


    // ========================================
    // SEND DATA TO BACKEND
    // ========================================

    try {

        const response = await fetch(
            "http://localhost:5000/api/voter/register",
            {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({

                    voter_number:
                        voter_number,

                    full_name:
                        full_name,

                    date_of_birth:
                        date_of_birth,

                    gender:
                        gender,

                    aadhaar:
                        aadhaar,

                    mobile:
                        mobile,

                    email:
                        email,

                    address:
                        address,

                    constituency:
                        constituency

                })

            }
        );


        const data =
            await response.json();


        // ========================================
        // REGISTRATION SUCCESS
        // ========================================

        if (response.ok) {

            console.log(
                "Registration Response:",
                data
            );


            // ========================================
            // GET NEW VOTER ID
            // ========================================

            const newVoterId =
                data.voter_id ||
                data.voterId ||
                data.id;


            // ========================================
            // CHECK VOTER ID
            // ========================================

            if (!newVoterId) {

                document.getElementById(
                    "message"
                ).innerHTML = `

                    <h3>
                        Voter Registered Successfully!
                    </h3>

                    <p>
                        But the server did not return
                        the new Voter ID.
                    </p>

                    <p>
                        Please contact the administrator.
                    </p>

                `;

                console.error(
                    "Voter ID missing from registration response:",
                    data
                );

                return;
            }


            // ========================================
            // SAVE VOTER ID TEMPORARILY
            // ========================================

            localStorage.setItem(
                "registered_voter_id",
                newVoterId
            );


            console.log(
                "New Voter ID:",
                newVoterId
            );


            // ========================================
            // SHOW SUCCESS
            // ========================================

            document.getElementById(
                "message"
            ).innerHTML = `

                <h3>
                    Voter Registered Successfully!
                </h3>

                <p>
                    Your Voter ID is:
                    <strong>${newVoterId}</strong>
                </p>

                <p>
                    Opening face registration...
                </p>

            `;


            // ========================================
            // OPEN FACE REGISTRATION
            // ========================================

            setTimeout(
                function() {

                    window.location.href =
                        "face_register.html";

                },
                1500
            );


        } else {

            // ========================================
            // REGISTRATION ERROR
            // ========================================

            document.getElementById(
                "message"
            ).innerHTML =
                data.message ||
                "Voter registration failed.";

        }


    } catch (error) {

        console.error(
            "Voter Registration Error:",
            error
        );


        document.getElementById(
            "message"
        ).innerHTML =
            "Unable to connect to server.";

    }

}