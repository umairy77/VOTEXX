async function registerCandidate() {

    try {

        const full_name =
            document.getElementById("full_name").value;

        const party_name =
            document.getElementById("party_name").value;

        const party_symbol =
            document.getElementById("party_symbol").value;

        const manifesto =
            document.getElementById("manifesto").value;

        const response = await fetch(
            "http://localhost:5000/api/candidate/register",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    full_name,
                    party_name,
                    party_symbol,
                    manifesto
                })
            }
        );

        const data = await response.json();

        document.getElementById("message").innerHTML =
            data.message;

    } catch (error) {

        console.error(error);

        document.getElementById("message").innerHTML =
            "Error: " + error.message;

    }
}