async function loginAdmin() {

    const email =
        document.getElementById("email").value.trim();

    const password =
        document.getElementById("password").value.trim();


    // Check fields

    if (!email || !password) {

        document.getElementById("message").innerHTML =
            "Please enter email and password.";

        return;
    }


    try {

        const response = await fetch(
            "http://localhost:5000/api/admin/login",
            {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    email: email,
                    password: password
                })

            }
        );


        const data = await response.json();


        // Show server message

        document.getElementById("message").innerHTML =
            data.message;


        // ========================================
        // LOGIN SUCCESS
        // ========================================

        if (response.ok) {

            // Save admin information

            localStorage.setItem(
                "admin_id",
                "admin"
            );

            localStorage.setItem(
                "admin_name",
                email
            );


            // Redirect to dashboard

            setTimeout(function () {

                window.location.href =
                    "admin_dashboard.html";

            }, 500);

        }


    } catch (error) {

        console.error(error);

        document.getElementById("message").innerHTML =
            "Unable to connect to server.";

    }

}