
// ========================================
// VOTEX - VOTER LOGIN
// ========================================


// ========================================
// LOGIN VOTER
// ========================================

async function loginVoter() {

    const voter_number =
        document.getElementById(
            "voter_number"
        ).value.trim();


    const mobile =
        document.getElementById(
            "mobile"
        ).value.trim();


    // ========================================
    // CHECK INPUT
    // ========================================

    if (!voter_number || !mobile) {

        document.getElementById(
            "message"
        ).innerHTML =
            "Please enter voter number and mobile number.";

        return;

    }


    try {

        const response = await fetch(
            "http://localhost:5000/api/voter/login",
            {

                method: "POST",

                headers: {

                    "Content-Type":
                        "application/json"

                },

                body: JSON.stringify({

                    voter_number,
                    mobile

                })

            }
        );


        const data =
            await response.json();


        // ========================================
        // DISPLAY MESSAGE
        // ========================================

        document.getElementById(
            "message"
        ).innerHTML =
            data.message || "Login successful.";


        // ========================================
        // LOGIN SUCCESSFUL
        // ========================================

        if (
            response.ok &&
            data.voter &&
            data.token
        ) {


            // ========================================
            // SAVE JWT TOKEN
            // ========================================

            localStorage.setItem(
                "voter_token",
                data.token
            );


            // ========================================
            // SAVE VOTER INFORMATION
            // ========================================

            localStorage.setItem(
                "voter_id",
                data.voter.voter_id
            );


            localStorage.setItem(
                "voter_name",
                data.voter.full_name
            );


            localStorage.setItem(
                "voter_number",
                data.voter.voter_number
            );


            // ========================================
            // REMOVE OLD FACE TOKEN
            // ========================================

            localStorage.removeItem(
                "face_token"
            );


            // ========================================
            // GO TO FACE VERIFICATION
            // ========================================

            setTimeout(() => {

                window.location.href =
                    "face_verify.html";

            }, 1000);

        }

    } catch (error) {

        console.error(
            "Voter Login Error:",
            error
        );


        document.getElementById(
            "message"
        ).innerHTML =
            "Unable to connect to server.";

    }

}



