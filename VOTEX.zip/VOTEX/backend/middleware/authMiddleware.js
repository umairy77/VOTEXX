const jwt = require("jsonwebtoken");


// ========================================
// VERIFY VOTER JWT
// ========================================

function authenticateVoter(req, res, next) {

    try {

        const authHeader =
            req.headers.authorization;


        // No authorization header

        if (!authHeader) {

            return res.status(401).json({

                message:
                    "Authentication token required"

            });

        }


        // Expected format:
        // Bearer TOKEN

        const parts =
            authHeader.split(" ");


        if (
            parts.length !== 2 ||
            parts[0] !== "Bearer"
        ) {

            return res.status(401).json({

                message:
                    "Invalid authorization format"

            });

        }


        const token = parts[1];


        // ========================================
        // VERIFY TOKEN
        // ========================================

        const decoded =
            jwt.verify(
                token,
                process.env.JWT_SECRET
            );


        // ========================================
        // STORE VOTER ID IN REQUEST
        // ========================================

        req.voter = decoded;


        next();

    }
    catch (error) {

        return res.status(401).json({

            message:
                "Invalid or expired authentication token"

        });

    }

}


module.exports = authenticateVoter;