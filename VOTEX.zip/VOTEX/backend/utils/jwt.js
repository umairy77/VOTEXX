const jwt = require("jsonwebtoken");

function generateToken(admin) {
    return jwt.sign(
        {
            admin_id: admin.admin_id,
            email: admin.email,
            role: admin.role
        },
        process.env.JWT_SECRET,
        {
            expiresIn: "24h"
        }
    );
}

module.exports = generateToken;