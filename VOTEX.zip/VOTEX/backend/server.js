const express = require("express");
const cors = require("cors");
const path = require("path");

require("dotenv").config();


// ========================================
// DATABASE
// ========================================

require("./config/database");


// ========================================
// ROUTES
// ========================================

const adminRoutes =
    require("./routes/adminRoutes");

const voterRoutes =
    require("./routes/voterRoutes");

const candidateRoutes =
    require("./routes/candidateRoutes");

const electionRoutes =
    require("./routes/electionRoutes");

const voteRoutes =
    require("./routes/voteRoutes");

const resultRoutes =
    require("./routes/resultRoutes");


// ========================================
// CREATE EXPRESS APP
// ========================================

const app = express();


// ========================================
// MIDDLEWARE
// ========================================

app.use(cors());

app.use(express.json());


// ========================================
// SERVE VOTEX FRONTEND
// ========================================

const frontendPath = path.join(__dirname, "../frontend");

app.use(express.static(frontendPath));


// ========================================
// API ROUTES
// ========================================

// Admin
app.use(
    "/api/admin",
    adminRoutes
);


// Voter
app.use(
    "/api/voter",
    voterRoutes
);


// Candidate
app.use(
    "/api/candidate",
    candidateRoutes
);


// Election
app.use(
    "/api/election",
    electionRoutes
);


// Vote
app.use(
    "/api/vote",
    voteRoutes
);


// Results
app.use(
    "/api/result",
    resultRoutes
);


// ========================================
// HOME PAGE
// ========================================

app.get("/", (req, res) => {

    res.sendFile(
        path.join(frontendPath, "index.html")
    );

});


// ========================================
// SERVER
// ========================================

const PORT =
    process.env.PORT || 5000;


app.listen(PORT, () => {

    console.log(
        `Server running on http://localhost:${PORT}`
    );

});