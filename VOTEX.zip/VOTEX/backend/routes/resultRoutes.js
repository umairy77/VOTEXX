const express = require("express");

const router = express.Router();

const resultController =
    require("../controllers/resultController");


// ========================================
// GET ELECTION RESULTS
// ========================================

router.get(
    "/:election_id",
    resultController.getResults
);


module.exports = router;