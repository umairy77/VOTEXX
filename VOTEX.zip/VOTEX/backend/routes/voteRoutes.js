const express = require("express");

const router = express.Router();

const voteController =
    require("../controllers/voteController");

const authenticateVoter =
    require("../middleware/authMiddleware");


// ========================================
// CAST VOTE
// ========================================

router.post(
    "/cast",
    authenticateVoter,
    voteController.castVote
);


// ========================================
// GET TOTAL VOTES
// ========================================

router.get(
    "/count/:election_id",
    voteController.getTotalVotes
);


module.exports = router;