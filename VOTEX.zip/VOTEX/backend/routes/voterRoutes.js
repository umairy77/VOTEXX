const express = require("express");

const router = express.Router();

const multer = require("multer");

const voterController =
    require("../controllers/voterController");

const authenticateVoter =
    require("../middleware/authMiddleware");


const upload =
    multer({
        storage: multer.memoryStorage()
    });


// ========================================
// REGISTER VOTER
// ========================================

router.post(
    "/register",
    voterController.registerVoter
);


// ========================================
// VOTER LOGIN
// ========================================

router.post(
    "/login",
    voterController.loginVoter
);
// ========================================
// VERIFY VOTER FACE
// ========================================

router.post(

    "/verify-face",

    authenticateVoter,

    upload.single("image"),

    voterController.verifyFace

);


// ========================================
// GET ALL VOTERS
// ========================================

router.get(
    "/all",
    authenticateVoter,
    voterController.getVoters
);


module.exports = router;