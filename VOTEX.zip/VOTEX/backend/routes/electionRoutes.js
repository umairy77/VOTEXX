const express = require("express");

const router = express.Router();

const electionController =
    require("../controllers/electionController");


// Create election
router.post(
    "/create",
    electionController.createElection
);


// Get active election
router.get(
    "/active",
    electionController.getActiveElection
);


module.exports = router;