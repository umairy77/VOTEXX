const Voter = require("../models/voterModel");
const jwt = require("jsonwebtoken");


// ========================================
// REGISTER VOTER
// ========================================

exports.registerVoter = (req, res) => {

    const {
        voter_number,
        full_name,
        date_of_birth,
        gender,
        aadhaar,
        mobile,
        email,
        address,
        constituency
    } = req.body;


    const voterData = {

        voter_number,
        full_name,
        date_of_birth,
        gender,
        aadhaar,
        mobile,
        email,
        address,
        constituency

    };


    Voter.createVoter(
        voterData,
        (err, result) => {

            if (err) {

                console.error(
                    "Voter Registration Error:",
                    err
                );

                return res.status(500).json({

                    message:
                        err.message

                });

            }


            // ========================================
            // GET NEW VOTER ID
            // ========================================

            const newVoterId =
                result.insertId;


            console.log(
                "New Voter ID:",
                newVoterId
            );


            // ========================================
            // SEND RESPONSE
            // ========================================

            res.status(201).json({

                message:
                    "Voter Registered Successfully",

                voter_id:
                    newVoterId

            });

        }
    );

};

// ========================================
// VOTER LOGIN
// ========================================

exports.loginVoter = (req, res) => {

    const {
        voter_number,
        mobile
    } = req.body;


    if (!voter_number || !mobile) {

        return res.status(400).json({

            message:
                "Voter number and mobile number are required."

        });

    }


    Voter.loginVoter(
        voter_number,
        mobile,
        (err, results) => {

            if (err) {

                return res.status(500).json({

                    message:
                        err.message

                });

            }


            if (results.length === 0) {

                return res.status(401).json({

                    message:
                        "Invalid voter number or mobile number."

                });

            }


            const voter = results[0];


            // ========================================
            // CREATE JWT TOKEN
            // ========================================

            const token = jwt.sign(

                {
                    voter_id:
                        voter.voter_id,

                    voter_number:
                        voter.voter_number
                },

                process.env.JWT_SECRET,

                {
                    expiresIn: "1h"
                }

            );


            // ========================================
            // SEND RESPONSE
            // ========================================

            res.status(200).json({

                message:
                    "Voter Login Successful",

                token: token,

                voter: {

                    voter_id:
                        voter.voter_id,

                    voter_number:
                        voter.voter_number,

                    full_name:
                        voter.full_name,

                    mobile:
                        voter.mobile,

                    email:
                        voter.email,

                    has_voted:
                        voter.has_voted

                }

            });

        }
    );

};


// ========================================
// GET ALL VOTERS
// ========================================

exports.getVoters = (req, res) => {

    Voter.getVoters(
        (err, results) => {

            if (err) {

                return res.status(500).json({

                    message:
                        err.message

                });

            }


            res.status(200).json(results);

        }
    );

};


// ========================================
// VERIFY VOTER FACE
// ========================================

exports.verifyFace = async (req, res) => {

    try {

        // ========================================
        // CHECK IMAGE
        // ========================================

        if (!req.file) {

            return res.status(400).json({

                success: false,

                verified: false,

                message:
                    "Face image is required."

            });

        }


        // ========================================
        // GET VOTER ID FROM JWT
        // ========================================

        const jwtVoterId =
            req.voter.voter_id;


        if (!jwtVoterId) {

            return res.status(401).json({

                success: false,

                verified: false,

                message:
                    "Voter identity not found in authentication token."

            });

        }


        // ========================================
        // SEND IMAGE TO PYTHON
        // ========================================

        const formData =
            new FormData();


        const imageBlob =
            new Blob(
                [req.file.buffer],
                {
                    type:
                        req.file.mimetype
                }
            );


        formData.append(
            "image",
            imageBlob,
            req.file.originalname
        );


        const pythonResponse =
            await fetch(
                "http://127.0.0.1:5001/verify-face",
                {
                    method: "POST",
                    body: formData
                }
            );


        const faceResult =
            await pythonResponse.json();


        // ========================================
        // PYTHON FACE VERIFICATION FAILED
        // ========================================

        if (
            !pythonResponse.ok ||
            !faceResult.verified
        ) {

            return res.status(401).json({

                success: true,

                verified: false,

                message:
                    faceResult.message ||
                    "Face verification failed."

            });

        }


        // ========================================
        // GET FACE VOTER ID
        // ========================================

        const faceVoterId =
            Number(faceResult.voter_id);


        const loggedInVoterId =
            Number(jwtVoterId);


        console.log(
            "JWT Voter ID:",
            loggedInVoterId
        );


        console.log(
            "Face Voter ID:",
            faceVoterId
        );


        // ========================================
        // CHECK FACE ID
        // ========================================

        if (
            faceVoterId !==
            loggedInVoterId
        ) {

            return res.status(403).json({

                success: true,

                verified: false,

                message:
                    "Face does not match the logged-in voter."

            });

        }


        // ========================================
        // CREATE FACE VERIFICATION TOKEN
        // ========================================

        const faceToken =
            jwt.sign(

                {
                    voter_id:
                        loggedInVoterId,

                    face_verified:
                        true
                },

                process.env.JWT_SECRET,

                {
                    expiresIn:
                        "5m"
                }

            );


        // ========================================
        // FACE VERIFIED SUCCESSFULLY
        // ========================================

        return res.status(200).json({

            success: true,

            verified: true,

            voter_id:
                loggedInVoterId,

            face_token:
                faceToken,

            message:
                "Face verified successfully.",

            confidence:
                faceResult.confidence

        });

    }
    catch (error) {

        console.error(
            "Face Verification Error:",
            error
        );


        return res.status(500).json({

            success: false,

            verified: false,

            message:
                "Face verification service unavailable."

        });

    }

};
