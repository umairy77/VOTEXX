const Candidate = require("../models/candidateModel");


exports.registerCandidate = (req, res) => {

    const {
        full_name,
        party_name,
        party_symbol,
        manifesto
    } = req.body;

    const candidateData = {
        full_name,
        party_name,
        party_symbol,
        manifesto
    };

    Candidate.createCandidate(candidateData, (err) => {

        if (err) {

            return res.status(500).json({
                message: err.message
            });

        }

        res.status(201).json({
            message: "Candidate Registered Successfully"
        });

    });

};


exports.getCandidates = (req, res) => {

    Candidate.getCandidates((err, results) => {

        if (err) {

            return res.status(500).json({
                message: err.message
            });

        }

        res.status(200).json(results);

    });

};