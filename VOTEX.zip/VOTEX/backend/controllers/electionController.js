const Election = require("../models/electionModel");


// ========================================
// CREATE ELECTION
// ========================================

exports.createElection = (req, res) => {

    const {
        election_name,
        election_type,
        start_date,
        end_date,
        status
    } = req.body;


    // Check required fields

    if (
        !election_name ||
        !election_type ||
        !start_date ||
        !end_date
    ) {

        return res.status(400).json({
            message: "Please fill all election details."
        });

    }


    const electionData = {

        election_name,
        election_type,
        start_date,
        end_date,
        status: status || "Upcoming"

    };


    Election.createElection(
        electionData,
        (err) => {

            if (err) {

                return res.status(500).json({
                    message: err.message
                });

            }


            res.status(201).json({

                message:
                    "Election Created Successfully"

            });

        }
    );

};


// ========================================
// GET ACTIVE ELECTION
// ========================================

exports.getActiveElection = (req, res) => {

    Election.getActiveElection(
        (err, results) => {

            if (err) {

                return res.status(500).json({

                    message: err.message

                });

            }


            // No active election

            if (results.length === 0) {

                return res.status(404).json({

                    message:
                        "No active election found."

                });

            }


            // Send active election

            res.status(200).json(
                results[0]
            );

        }
    );

};