const Result = require("../models/resultModel");


// ========================================
// GET ELECTION RESULTS
// ========================================

exports.getResults = (req, res) => {

    const election_id = req.params.election_id;


    // Check election ID

    if (!election_id) {

        return res.status(400).json({

            message: "Election ID is required."

        });

    }


    Result.getResults(
        election_id,
        (err, results) => {

            if (err) {

                console.log(
                    "Result Error:",
                    err.message
                );

                return res.status(500).json({

                    message:
                        err.message

                });

            }


            // Send results

            res.status(200).json({

                election_id:
                    election_id,

                results:
                    results

            });

        }
    );

};