const bcrypt = require("bcrypt");
const Admin = require("../models/adminModel");
const generateToken = require("../utils/jwt");

// Register Admin
exports.registerAdmin = async (req, res) => {
    try {
        const { full_name, email, password, role } = req.body;

        if (!full_name || !email || !password) {
            return res.status(400).json({
                message: "Please fill all required fields."
            });
        }

        // Check if email already exists
        Admin.getAdminByEmail(email, async (err, result) => {
            if (err) {
                return res.status(500).json({ message: err.message });
            }

            if (result.length > 0) {
                return res.status(400).json({
                    message: "Admin already exists."
                });
            }

            // Encrypt Password
            const hashedPassword = await bcrypt.hash(password, 10);

            const adminData = {
                full_name,
                email,
                password_hash: hashedPassword,
                role: role || "Election Officer"
            };

            Admin.createAdmin(adminData, (err) => {
                if (err) {
                    return res.status(500).json({
                        message: err.message
                    });
                }

                res.status(201).json({
                    message: "Admin registered successfully."
                });
            });
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// Login Admin
exports.loginAdmin = (req, res) => {

    const { email, password } = req.body;

    Admin.getAdminByEmail(email, async (err, result) => {

        if (err)
            return res.status(500).json({
                message: err.message
            });

        if (result.length === 0)
            return res.status(404).json({
                message: "Admin not found."
            });

        const admin = result[0];

        const match = await bcrypt.compare(
            password,
            admin.password_hash
        );

        if (!match)
            return res.status(401).json({
                message: "Invalid Password"
            });

        const token = generateToken(admin);

        res.json({
            message: "Login Successful",
            token
        });

    });

};