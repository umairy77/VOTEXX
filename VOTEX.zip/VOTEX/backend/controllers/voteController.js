const Vote = require("../models/voteModel");
const jwt = require("jsonwebtoken");


// ========================================
// CAST VOTE
// ========================================

exports.castVote = (req, res) => {

    const {
        election_id,
        candidate_id
    } = req.body;


    // ========================================
    // GET VOTER ID FROM JWT
    // ========================================

    const voter_id =
        req.voter.voter_id;


    // ========================================
    // CHECK JWT VOTER
    // ========================================

    if (!voter_id) {

        return res.status(401).json({

            message:
                "Invalid voter authentication."

        });

    }


    // ========================================
    // GET FACE VERIFICATION TOKEN
    // ========================================

    const face_token =
        req.headers["x-face-token"];


    // ========================================
    // CHECK FACE TOKEN
    // ========================================

    if (!face_token) {

        return res.status(403).json({

            message:
                "Face verification required before voting."

        });

    }


    // ========================================
    // VERIFY FACE TOKEN
    // ========================================

    try {

        const faceData =
            jwt.verify(
                face_token,
                process.env.JWT_SECRET
            );


        // ========================================
        // CHECK FACE VERIFIED FLAG
        // ========================================

        if (
            faceData.face_verified !== true
        ) {

            return res.status(403).json({

                message:
                    "Invalid face verification."

            });

        }


        // ========================================
        // CHECK VOTER ID MATCH
        // ========================================

        if (
            Number(faceData.voter_id) !==
            Number(voter_id)
        ) {

            return res.status(403).json({

                message:
                    "Face verification does not match logged-in voter."

            });

        }

    }
    catch (error) {

        console.log(
            "Face Token Error:",
            error.message
        );


        return res.status(403).json({

            message:
                "Face verification expired. Please verify your face again."

        });

    }


    // ========================================
    // CHECK REQUIRED FIELDS
    // ========================================

    if (
        !election_id ||
        !candidate_id
    ) {

        return res.status(400).json({

            message:
                "Election and candidate are required."

        });

    }


    // ========================================
    // CREATE VOTE DATA
    // ========================================

    const voteData = {

        election_id,
        candidate_id,
        voter_id

    };


    // ========================================
    // CAST VOTE
    // ========================================

    Vote.castVote(
        voteData,
        (err, result) => {

            if (err) {

                console.log(
                    "Vote Error:",
                    err.message
                );


                return res.status(500).json({

                    message:
                        err.message

                });

            }


            console.log(
                "Vote Result:",
                result
            );


            // ========================================
            // SUCCESS
            // ========================================

            return res.status(201).json({

                message:
                    "Vote Cast Successfully",

                receipt_code:
                    result.receipt_code,

                blockchain_hash:
                    result.blockchain_hash

            });

        }
    );

};


// ========================================
// GET TOTAL VOTES
// ========================================

exports.getTotalVotes = (req, res) => {

    const election_id =
        req.params.election_id;


    if (!election_id) {

        return res.status(400).json({

            message:
                "Election ID is required."

        });

    }


    Vote.getTotalVotes(
        election_id,
        (err, results) => {

            if (err) {

                console.log(
                    "Vote Count Error:",
                    err.message
                );


                return res.status(500).json({

                    message:
                        err.message

                });

            }


            const total_votes =
                results[0].total_votes;


            res.status(200).json({

                election_id:
                    election_id,

                total_votes:
                    total_votes

            });

        }
    );

};