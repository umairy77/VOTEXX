const db = require("../config/database");
const Receipt = require("./receiptModel");
const crypto = require("crypto");

// ========================================
// CAST VOTE - SECURE TRANSACTION
// ========================================
function castVote(voteData, callback) {

    // START TRANSACTION
    db.beginTransaction((err) => {

        if (err) {
            return callback(err);
        }

        // ========================================
        // 1. LOCK VOTER ROW
        // ========================================
        const checkVoterSQL = `
            SELECT
                voter_id,
                has_voted
            FROM voters
            WHERE voter_id = ?
            FOR UPDATE
        `;

        db.query(
            checkVoterSQL,
            [voteData.voter_id],
            (err, voterResults) => {

                if (err) {
                    return rollback(err);
                }

                if (voterResults.length === 0) {
                    return rollback(
                        new Error("Voter not found")
                    );
                }

                if (voterResults[0].has_voted == 1) {
                    return rollback(
                        new Error("Voter has already voted")
                    );
                }

                // ========================================
                // 2. CHECK ACTIVE ELECTION
                // ========================================
                const checkElectionSQL = `
                    SELECT
                        election_id,
                        election_name,
                        status
                    FROM elections
                    WHERE election_id = ?
                    AND status = 'Active'
                `;

                db.query(
                    checkElectionSQL,
                    [voteData.election_id],
                    (err, electionResults) => {

                        if (err) {
                            return rollback(err);
                        }

                        if (electionResults.length === 0) {
                            return rollback(
                                new Error("Election is not active")
                            );
                        }

                        // ========================================
                        // 3. CHECK CANDIDATE
                        // ========================================
                        const checkCandidateSQL = `
                            SELECT
                                candidate_id,
                                full_name,
                                election_id,
                                is_active
                            FROM candidates
                            WHERE candidate_id = ?
                        `;

                        db.query(
                            checkCandidateSQL,
                            [voteData.candidate_id],
                            (err, candidateResults) => {

                                if (err) {
                                    return rollback(err);
                                }

                                if (candidateResults.length === 0) {
                                    return rollback(
                                        new Error("Candidate not found")
                                    );
                                }

                                const candidate =
                                    candidateResults[0];

                                // ========================================
                                // 4. CHECK CANDIDATE BELONGS TO ELECTION
                                // ========================================
                                if (
                                    candidate.election_id !=
                                    voteData.election_id
                                ) {
                                    return rollback(
                                        new Error(
                                            "Candidate does not belong to this election"
                                        )
                                    );
                                }

                                // ========================================
                                // 5. CHECK CANDIDATE ACTIVE
                                // ========================================
                                if (candidate.is_active == 0) {
                                    return rollback(
                                        new Error(
                                            "Candidate is not active"
                                        )
                                    );
                                }

                                // ========================================
                                // 6. CREATE BLOCKCHAIN HASH
                                // ========================================
                                const voteString =
                                    voteData.election_id +
                                    "-" +
                                    voteData.candidate_id +
                                    "-" +
                                    voteData.voter_id +
                                    "-" +
                                    Date.now();

                                const blockchain_hash =
                                    crypto
                                        .createHash("sha256")
                                        .update(voteString)
                                        .digest("hex");

                                console.log(
                                    "Blockchain Hash:",
                                    blockchain_hash
                                );

                                // ========================================
                                // 7. INSERT VOTE
                                // ========================================
                                const insertVoteSQL = `
                                    INSERT INTO votes
                                    (
                                        election_id,
                                        candidate_id,
                                        voter_id,
                                        blockchain_hash
                                    )
                                    VALUES (?, ?, ?, ?)
                                `;

                                db.query(
                                    insertVoteSQL,
                                    [
                                        voteData.election_id,
                                        voteData.candidate_id,
                                        voteData.voter_id,
                                        blockchain_hash
                                    ],
                                    (err, result) => {

                                        if (err) {
                                            return rollback(err);
                                        }

                                        // ========================================
                                        // 8. UPDATE VOTER
                                        // ========================================
                                        const updateVoterSQL = `
                                            UPDATE voters
                                            SET has_voted = 1
                                            WHERE voter_id = ?
                                        `;

                                        db.query(
                                            updateVoterSQL,
                                            [voteData.voter_id],
                                            (err) => {

                                                if (err) {
                                                    return rollback(err);
                                                }

                                                // ========================================
                                                // 9. CREATE RECEIPT
                                                // ========================================
                                                Receipt.createReceipt(
                                                    voteData.voter_id,
                                                    (err, receipt_code) => {

                                                        if (err) {
                                                            return rollback(err);
                                                        }

                                                        // ========================================
                                                        // 10. COMMIT TRANSACTION
                                                        // ========================================
                                                        db.commit(
                                                            (err) => {

                                                                if (err) {
                                                                    return rollback(err);
                                                                }

                                                                callback(
                                                                    null,
                                                                    {
                                                                        receipt_code:
                                                                            receipt_code,
                                                                        blockchain_hash:
                                                                            blockchain_hash
                                                                    }
                                                                );
                                                            }
                                                        );
                                                    }
                                                );
                                            }
                                        );
                                    }
                                );
                            }
                        );
                    }
                );
            }
        );

        // ========================================
        // ROLLBACK FUNCTION
        // ========================================
        function rollback(error) {

            db.rollback(() => {
                callback(error);
            });
        }
    });
}

// ========================================
// GET TOTAL VOTES
// ========================================
function getTotalVotes(election_id, callback) {

    const sql = `
        SELECT
            COUNT(*) AS total_votes
        FROM votes
        WHERE election_id = ?
    `;

    db.query(
        sql,
        [election_id],
        callback
    );
}

// ========================================
// EXPORT
// ========================================
module.exports = {
    castVote,
    getTotalVotes
};