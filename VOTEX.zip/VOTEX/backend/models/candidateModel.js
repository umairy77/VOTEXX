const db = require("../config/database");

function createCandidate(candidateData, callback) {

    const sql = `
        INSERT INTO candidates
        (
            full_name,
            party_name,
            party_symbol,
            manifesto
        )
        VALUES (?, ?, ?, ?)
    `;

    db.query(sql, [
        candidateData.full_name,
        candidateData.party_name,
        candidateData.party_symbol,
        candidateData.manifesto
    ], callback);
}


function getCandidates(callback) {

    const sql = `
        SELECT
            candidate_id,
            full_name,
            party_name,
            party_symbol,
            manifesto
        FROM candidates
        WHERE is_active = TRUE
    `;

    db.query(sql, callback);
}


module.exports = {
    createCandidate,
    getCandidates
};