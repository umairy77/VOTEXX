const db = require("../config/database");


// ========================================
// REGISTER VOTER
// ========================================

function createVoter(voterData, callback) {

    const sql = `
        INSERT INTO voters
        (
            voter_number,
            full_name,
            date_of_birth,
            gender,
            aadhaar,
            mobile,
            email,
            address,
            constituency
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;


    db.query(
        sql,
        [

            voterData.voter_number,
            voterData.full_name,
            voterData.date_of_birth,
            voterData.gender,
            voterData.aadhaar,
            voterData.mobile,
            voterData.email,
            voterData.address,
            voterData.constituency

        ],

        (err, result) => {

            if (err) {

                callback(err);

                return;

            }


            // ========================================
            // RETURN MYSQL RESULT
            // ========================================

            callback(null, result);

        }
    );

}


// ========================================
// FIND VOTER FOR LOGIN
// ========================================

function loginVoter(
    voter_number,
    mobile,
    callback
) {

    const sql = `
        SELECT
            voter_id,
            voter_number,
            full_name,
            mobile,
            email,
            has_voted
        FROM voters
        WHERE voter_number = ?
        AND mobile = ?
        LIMIT 1
    `;


    db.query(
        sql,
        [
            voter_number,
            mobile
        ],
        callback
    );

}


// ========================================
// GET ALL VOTERS
// ========================================

function getVoters(callback) {

    const sql = `
        SELECT
            voter_id,
            voter_number,
            full_name,
            gender,
            mobile,
            email,
            constituency,
            has_voted
        FROM voters
        ORDER BY voter_id DESC
    `;


    db.query(
        sql,
        callback
    );

}


// ========================================
// EXPORT
// ========================================

module.exports = {

    createVoter,

    loginVoter,

    getVoters

};