const db = require("../config/database");


// ========================================
// CREATE ELECTION
// ========================================

function createElection(electionData, callback) {

    const sql = `
        INSERT INTO elections
        (
            election_name,
            election_type,
            start_date,
            end_date,
            status
        )
        VALUES (?, ?, ?, ?, ?)
    `;

    db.query(sql, [

        electionData.election_name,
        electionData.election_type,
        electionData.start_date,
        electionData.end_date,
        electionData.status

    ], callback);
}


// ========================================
// GET ACTIVE ELECTION
// ========================================

function getActiveElection(callback) {

    const sql = `
        SELECT
            election_id,
            election_name,
            election_type,
            start_date,
            end_date,
            status
        FROM elections
        WHERE status = 'Active'
        LIMIT 1
    `;

    db.query(sql, callback);
}


// ========================================
// EXPORT FUNCTIONS
// ========================================

module.exports = {

    createElection,
    getActiveElection

};