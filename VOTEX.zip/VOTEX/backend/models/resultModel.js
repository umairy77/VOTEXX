const db = require("../config/database");

function getResults(election_id, callback) {

    const sql = `
        SELECT
            c.candidate_id,
            c.full_name,
            c.party_name,
            COUNT(v.vote_id) AS vote_count
        FROM candidates c
        LEFT JOIN votes v
            ON c.candidate_id = v.candidate_id
            AND v.election_id = ?
        GROUP BY
            c.candidate_id,
            c.full_name,
            c.party_name
        ORDER BY vote_count DESC
    `;

    db.query(
        sql,
        [election_id],
        (err, results) => {

            if (err) {
                return callback(err);
            }

            callback(null, results);
        }
    );
}

module.exports = {
    getResults
};