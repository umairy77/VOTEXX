const db = require("../config/database");

function createAdmin(adminData, callback) {
    const sql = `
        INSERT INTO admins (full_name, email, password_hash, role)
        VALUES (?, ?, ?, ?)
    `;

    db.query(
        sql,
        [
            adminData.full_name,
            adminData.email,
            adminData.password_hash,
            adminData.role
        ],
        callback
    );
}

function getAdminByEmail(email, callback) {
    const sql = "SELECT * FROM admins WHERE email = ?";

    db.query(sql, [email], callback);
}

module.exports = {
    createAdmin,
    getAdminByEmail
};