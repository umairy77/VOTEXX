const db = require("../config/database");


// ========================================
// CREATE RECEIPT
// ========================================

function createReceipt(voter_id, callback) {

    // Generate a unique receipt code

    const receipt_code =
        "VOTEX-" +
        Date.now() +
        "-" +
        Math.floor(
            1000 + Math.random() * 9000
        );


    const sql = `
        INSERT INTO receipts
        (
            voter_id,
            receipt_code
        )
        VALUES (?, ?)
    `;


    db.query(
        sql,
        [
            voter_id,
            receipt_code
        ],
        (err, result) => {

            if (err) {

                return callback(err);

            }


            // Return the receipt code

            callback(
                null,
                receipt_code
            );

        }
    );

}


module.exports = {

    createReceipt

};