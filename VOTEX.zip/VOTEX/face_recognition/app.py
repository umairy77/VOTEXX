from flask import Flask, jsonify, request
from flask_cors import CORS
import cv2
import os
import numpy as np

app = Flask(__name__)
CORS(app)

# ========================================
# SETTINGS
# ========================================

MODEL_PATH = "voter_model.yml"
DATASET_PATH = "dataset"

# Create dataset folder if it doesn't exist
os.makedirs(DATASET_PATH, exist_ok=True)


# ========================================
# FACE DETECTOR
# ========================================

face_detector = cv2.CascadeClassifier(
    cv2.data.haarcascades +
    "haarcascade_frontalface_default.xml"
)

if face_detector.empty():
    print("❌ Face detector could not be loaded")
else:
    print("✅ Face detector loaded")


# ========================================
# FACE RECOGNIZER
# ========================================

recognizer = cv2.face.LBPHFaceRecognizer_create()

model_loaded = False


if os.path.exists(MODEL_PATH):

    try:

        recognizer.read(MODEL_PATH)

        model_loaded = True

        print("✅ Existing face model loaded")

    except Exception as error:

        print(
            "❌ Could not load face model:",
            error
        )

else:

    print(
        "⚠️ voter_model.yml not found."
    )

    print(
        "⚠️ A new model will be created."
    )


# ========================================
# HOME
# ========================================

@app.route("/")
def home():

    return jsonify({
        "message":
            "VOTEX Face Recognition Service is running"
    })


# ========================================
# VERIFY FACE
# ========================================

@app.route(
    "/verify-face",
    methods=["POST"]
)
def verify_face():

    if "image" not in request.files:

        return jsonify({
            "success": False,
            "verified": False,
            "message":
                "No image received"
        }), 400


    if not model_loaded:

        return jsonify({
            "success": False,
            "verified": False,
            "message":
                "Face recognition model is not available"
        }), 500


    image_file = request.files["image"]


    # ========================================
    # READ IMAGE
    # ========================================

    image_bytes = image_file.read()

    image_array = np.frombuffer(
        image_bytes,
        np.uint8
    )

    image = cv2.imdecode(
        image_array,
        cv2.IMREAD_COLOR
    )


    if image is None:

        return jsonify({
            "success": False,
            "verified": False,
            "message":
                "Could not read uploaded image"
        }), 400


    # ========================================
    # GRAYSCALE
    # ========================================

    gray = cv2.cvtColor(
        image,
        cv2.COLOR_BGR2GRAY
    )


    # ========================================
    # DETECT FACE
    # ========================================

    faces = face_detector.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(80, 80)
    )


    if len(faces) == 0:

        return jsonify({
            "success": True,
            "verified": False,
            "message":
                "No face detected"
        })


    if len(faces) > 1:

        return jsonify({
            "success": True,
            "verified": False,
            "message":
                "Multiple faces detected. Please keep only one person in front of the camera."
        })


    # ========================================
    # EXTRACT FACE
    # ========================================

    x, y, w, h = faces[0]

    face = gray[
        y:y + h,
        x:x + w
    ]


    # ========================================
    # PREDICT
    # ========================================

    label, confidence = recognizer.predict(
        face
    )


    print(
        "Predicted voter ID:",
        label
    )

    print(
        "Confidence:",
        confidence
    )


    # Lower confidence = better match
    threshold = 80


    # ========================================
    # SUCCESS
    # ========================================

    if confidence < threshold:

        return jsonify({

            "success": True,

            "verified": True,

            "voter_id":
                int(label),

            "message":
                "Face verified successfully",

            "confidence":
                round(
                    float(confidence),
                    2
                )
        })


    # ========================================
    # FAILED
    # ========================================

    return jsonify({

        "success": True,

        "verified": False,

        "message":
            "Face verification failed",

        "confidence":
            round(
                float(confidence),
                2
            )
    })


# ========================================
# REGISTER / ENROLL FACE
# ========================================

@app.route(
    "/register-face",
    methods=["POST"]
)
def register_face():

    # ========================================
    # GET VOTER ID
    # ========================================

    voter_id = request.form.get(
        "voter_id"
    )


    if not voter_id:

        return jsonify({
            "success": False,
            "message":
                "Voter ID is required"
        }), 400


    try:

        voter_id = int(voter_id)

    except ValueError:

        return jsonify({
            "success": False,
            "message":
                "Invalid Voter ID"
        }), 400


    # ========================================
    # CHECK IMAGE
    # ========================================

    if "image" not in request.files:

        return jsonify({
            "success": False,
            "message":
                "No face image received"
        }), 400


    image_file = request.files["image"]


    # ========================================
    # READ IMAGE
    # ========================================

    image_bytes = image_file.read()

    image_array = np.frombuffer(
        image_bytes,
        np.uint8
    )

    image = cv2.imdecode(
        image_array,
        cv2.IMREAD_COLOR
    )


    if image is None:

        return jsonify({
            "success": False,
            "message":
                "Could not read image"
        }), 400


    # ========================================
    # GRAYSCALE
    # ========================================

    gray = cv2.cvtColor(
        image,
        cv2.COLOR_BGR2GRAY
    )


    # ========================================
    # DETECT FACE
    # ========================================

    faces = face_detector.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(80, 80)
    )


    if len(faces) == 0:

        return jsonify({
            "success": False,
            "message":
                "No face detected"
        })


    if len(faces) > 1:

        return jsonify({
            "success": False,
            "message":
                "Multiple faces detected. Only one face is allowed."
        })


    # ========================================
    # GET FACE
    # ========================================

    x, y, w, h = faces[0]

    face = gray[
        y:y + h,
        x:x + w
    ]


    # Resize face for consistency
    face = cv2.resize(
        face,
        (200, 200)
    )


    # ========================================
    # CREATE VOTER DATASET FOLDER
    # ========================================

    voter_folder = os.path.join(
        DATASET_PATH,
        str(voter_id)
    )

    os.makedirs(
        voter_folder,
        exist_ok=True
    )


    # ========================================
    # COUNT EXISTING SAMPLES
    # ========================================

    existing_files = [
        file
        for file in os.listdir(
            voter_folder
        )
        if file.lower().endswith(
            (".jpg", ".jpeg", ".png")
        )
    ]


    sample_number = (
        len(existing_files) + 1
    )


    # ========================================
    # SAVE FACE SAMPLE
    # ========================================

    image_path = os.path.join(
        voter_folder,
        f"face_{sample_number}.jpg"
    )


    cv2.imwrite(
        image_path,
        face
    )


    # ========================================
    # UPDATE MODEL
    # ========================================

    global model_loaded

    try:

        recognizer.update(
            [face],
            np.array(
                [voter_id],
                dtype=np.int32
            )
        )

        recognizer.write(
            MODEL_PATH
        )

        model_loaded = True

        print(
            f"✅ Face sample registered for voter {voter_id}"
        )

        print(
            f"📁 Saved: {image_path}"
        )


    except Exception as error:

        print(
            "❌ Model update error:",
            error
        )

        return jsonify({
            "success": False,
            "message":
                "Face model could not be updated"
        }), 500


    # ========================================
    # RESPONSE
    # ========================================

    return jsonify({

        "success": True,

        "message":
            "Face sample registered successfully",

        "voter_id":
            voter_id,

        "sample_number":
            sample_number

    })


# ========================================
# START SERVER
# ========================================

if __name__ == "__main__":

    app.run(
        host="127.0.0.1",
        port=5001,
        debug=True
    )