import cv2
import os
import numpy as np

# ==============================
# PATHS
# ==============================

image_path = os.path.join("faces", "voter_1.jpg")
model_path = "voter_model.yml"

# ==============================
# CHECK IMAGE
# ==============================

if not os.path.exists(image_path):
    print("❌ voter_1.jpg not found")
    exit()

image = cv2.imread(image_path)

if image is None:
    print("❌ Could not read voter_1.jpg")
    exit()

# ==============================
# LOAD FACE DETECTOR
# ==============================

face_detector = cv2.CascadeClassifier(
    cv2.data.haarcascades +
    "haarcascade_frontalface_default.xml"
)

gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

faces = face_detector.detectMultiScale(
    gray,
    scaleFactor=1.1,
    minNeighbors=5,
    minSize=(80, 80)
)

# ==============================
# CHECK FACE
# ==============================

if len(faces) == 0:
    print("❌ No face detected")
    exit()

if len(faces) > 1:
    print("❌ Multiple faces detected")
    exit()

print("✅ One face detected")

# ==============================
# CROP FACE
# ==============================

x, y, w, h = faces[0]

face = gray[y:y+h, x:x+w]

# ==============================
# CREATE LBPH RECOGNIZER
# ==============================

recognizer = cv2.face.LBPHFaceRecognizer_create()

# Voter 1 = label 1
recognizer.train(
    [face],
    np.array([1], dtype=np.int32)
)

# ==============================
# SAVE MODEL
# ==============================

recognizer.write(model_path)

print("✅ Face model trained successfully")
print("✅ Model saved as:", model_path)