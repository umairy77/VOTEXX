@echo off
title VOTEX Complete Prototype
echo ========================================
echo             VOTEX PROTOTYPE
echo ========================================
echo.
echo Starting Backend Server...
start "VOTEX Backend" cmd /k "cd /d %~dp0backend && npm run dev"
echo.
echo Starting Face Recognition Service...
start "VOTEX Face Service" cmd /k "cd /d %~dp0face_recognition && python app.py"
echo.
echo Waiting for services to start...
timeout /t 5 /nobreak >nul
echo Opening VOTEX website...
start "" "http://localhost:5000"
echo.
echo VOTEX is starting.
echo Keep the two server windows open while demonstrating.
echo.
pause
