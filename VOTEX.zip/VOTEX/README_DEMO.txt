VOTEX COMPLETE PROTOTYPE
=========================

STARTING THE PROJECT
--------------------
1. Make sure MySQL is running.
2. Double-click START_VOTEX.bat.
3. The backend and face-recognition service will open in separate Command Prompt windows.
4. Your browser will open:
   http://localhost:5000

IMPORTANT
---------
Do not close the Backend or Face Recognition Command Prompt windows during the demo.

MAIN DEMO FLOW
--------------
Home
 -> Voter Register
 -> Face Registration
 -> Voter Login
 -> Face Verification
 -> Vote
 -> Receipt + Blockchain Hash
 -> Results

ADMIN FLOW
----------
Home
 -> Admin Login
 -> Admin Dashboard
 -> Create Election
 -> Register Candidate
 -> View Results
 -> Manage Voters

PROJECT PORTS
-------------
Backend: http://localhost:5000
Face service: http://127.0.0.1:5001

If START_VOTEX.bat cannot start Python because the command is named differently
on your computer, run the face service manually from:
face_recognition\
with:
python app.py

BACKUP
------
Keep a backup of the working voter_model.yml and the MySQL database before making
major changes.
